# On Screen Keyboard
A virtual keyboard application build in Java. Similar to On-Screen Keyboard application in windows. 

<h2>How to run the application</h2>
<ol>
<li>To run the application you must have Java installed on your machine. Download the latest version of java from <a href='http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html'>Oracle</a>. </li>
<li>Go to the <code>dist</code> directory and run <code>OnscreenKeyboard.jar</code>.</li>
</ol>

![On Screen Keyboard](https://github.com/PankajPrakashh/On-Screen-Keyboard/blob/master/capture1.PNG?raw=true "On screen keyboard screenshot")

Hope you liked it :)
